# USER FLOW
## Giáo viên
Login → Room → Subject/Class → Topic → Lesson → Equipment → Confirm → Receipt → Return.

## Chọn thiết bị
Checkbox = selected only. Confirm = transaction.
Quantity không vượt available.

## Trả
My receipts → Borrowed → Return → kiểm tra tình trạng → Confirm return → Returned.

## Qua ngày
At date change, teacher edit permission = false. Record remains BORROWED until actual return. No automatic return.

## Admin
Admin Dashboard → inventory/current borrowers → receipt → unlock with reason → edit permitted fields → relock/audit.
