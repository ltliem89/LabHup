# REPORTING / EXPORT
## Teacher
Only own records.
Filters: week, month, year, custom date range.
Exports: Excel, PDF, print.

## Admin
All authorized data with filters by teacher, room, subject, class, topic, lesson, equipment, date and status.

## Privacy
Teacher reports must be server-filtered by teacher_id; never rely only on frontend filtering.

## Suggested personal report columns
Date, borrow_id, room, subject, class, topic, lesson, equipment, quantity, borrowed_at, returned_at, status.
