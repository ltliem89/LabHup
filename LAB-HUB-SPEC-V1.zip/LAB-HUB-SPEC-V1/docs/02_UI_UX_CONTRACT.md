# UI/UX CONTRACT V1.0
## Màu
Primary #1677FF; Dark #0B2A5B; Background #F7F9FC; White #FFFFFF; Text #172033; Secondary #667085; Border #D9E2F0; Success #22C55E; Warning #F59E0B; Danger #EF4444.

## Flow
01 Login
02 Room
03 Subject + Class
04 Topic/Chapter
05 Lesson
06 Equipment
07 Borrow confirmation
08 Borrow success
09 My receipt
10 Return

## Quy tắc
- Chọn phòng: các phòng khác biến mất, chuyển sang chi tiết phòng.
- Môn và lớp nằm cùng ngữ cảnh.
- Topic hiển thị sau môn/lớp.
- Lesson hiển thị sau topic.
- Screen 06: header 48–52px, context bar 32–36px, search 44px, equipment 1-column.
- Equipment row 68–76px; touch target ≥44px.
- Bottom action fixed; chỉ enabled khi đã chọn ít nhất 1 thiết bị.
- Không dùng grid cho equipment trên mobile.
- Back phải giữ state đang chọn.
