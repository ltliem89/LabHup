# ACCOUNT MANAGEMENT
## Teacher account
Fields:
teacher_id
email
display_name
role
status
authorized_room_ids
created_at
updated_at

## Admin
Can activate/deactivate teacher, assign rooms, change role according to policy.

## Deactivation
Do not delete historical records. Set status INACTIVE.

## Access principle
A teacher must not access data by changing teacher_id in a URL/request. Server-side authorization is mandatory.
