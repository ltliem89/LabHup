# TOPIC → EQUIPMENT MAPPING
Thiết bị được quản lý theo Chủ đề/Chương, không theo từng bài.

Ví dụ:
PHY-8-C1 → PHY-EQ-001 Cân điện tử
PHY-8-C1 → PHY-EQ-002 Quả cân 50g
PHY-8-C1 → PHY-EQ-003 Quả cân 100g

LESSONS chỉ cung cấp ngữ cảnh cho Borrow Record.

Fields:
topic_code, equipment_code, default_quantity, required, note, active.

Admin có thể import hàng loạt hoặc chỉnh sửa mapping trực tiếp.
