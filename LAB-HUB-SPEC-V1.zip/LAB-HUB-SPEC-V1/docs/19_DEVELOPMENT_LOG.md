# DEVELOPMENT LOG
Use one entry per meaningful change.

## Entry template
Date:
Phase/Gate:
Task:
Requester decision:
Files changed:
Implementation:
Tests run:
Result:
Known issues:
Next step:
Commit:
Deployment:
Notes:

## Status vocabulary
PLANNED
IN_PROGRESS
BLOCKED
PASS
FAIL
DONE

## Rule
A phase is DONE only when implementation and verification evidence are recorded.
