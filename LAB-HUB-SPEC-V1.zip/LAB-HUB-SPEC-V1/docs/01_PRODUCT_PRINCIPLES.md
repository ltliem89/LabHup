# PRODUCT PRINCIPLES
1. Mobile-first.
2. Ít thao tác.
3. Context càng sâu càng gọn.
4. Equipment list luôn ưu tiên diện tích.
5. Không AI đoán nghiệp vụ.
6. Explicit action: người dùng chọn và xác nhận.
7. Inventory là dữ liệu giao dịch, không sửa tùy tiện.
8. Privacy by default: giáo viên chỉ thấy dữ liệu của mình.
9. Auditability: thao tác quan trọng phải truy vết được.
10. Import an toàn: validate → preview → confirm → log.
