# BORROW / RETURN ENGINE
## Borrow
1. Receive teacher + context + selected items.
2. Validate permission.
3. Acquire lock/transaction guard.
4. Re-read current inventory.
5. Validate every requested quantity.
6. Create BORROW_RECORD.
7. Create BORROW_ITEMS.
8. Update/recalculate availability.
9. Write AUDIT_LOG.
10. Return receipt.

## Return
1. Validate owner or Admin.
2. Load active borrow items.
3. Record returned quantities and incidents.
4. Mark record RETURNED when all items returned.
5. Recalculate availability.
6. Write RETURN event + AUDIT_LOG.

## Concurrency
Apps Script must use LockService around final inventory check + write. Never trust client-side availability.

## Same-day edit
Teacher may edit own record on same calendar date, subject to rules. Any inventory-changing edit must be validated atomically.

## Past-day lock
After local calendar date changes, teacher edit = denied. Actual return remains allowed.

## Admin unlock
Admin must provide reason. Unlock is time-stamped and audited. Do not silently erase the original state.
