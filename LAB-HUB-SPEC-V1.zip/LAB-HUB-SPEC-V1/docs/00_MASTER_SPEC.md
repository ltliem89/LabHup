# LAB HUB — MASTER SPEC V1.0
## Hệ thống quản lý mượn — trả thiết bị phòng thực hành

### 1. Mục tiêu
LAB HUB là PWA mobile-first cho giáo viên quản lý mượn/trả thiết bị tại 4 phòng:
- PHY — Phòng Vật lý
- CHEM_BIO — Phòng Hóa–Sinh
- STEM — Phòng STEM
- ROBOT — Phòng Robotics

Quy mô ban đầu khoảng 4–5 giáo viên. Ưu tiên đơn giản, dễ dùng, dễ quản trị, không dựng VPS.

### 2. Kiến trúc
Google AI Studio: UI/prototype → GitHub: source + spec → Vercel: web/PWA → Apps Script: API/nghiệp vụ → Google Sheets: dữ liệu → Google Drive: file/ảnh/báo cáo.

### 3. Nguyên tắc nghiệp vụ
1. Thiết bị thuộc kho, không thuộc bài.
2. Thiết bị được liên kết với Chủ đề/Chương.
3. Bài được lưu trong phiếu để xác định ngữ cảnh dạy học.
4. Tick checkbox chỉ là lựa chọn tạm thời; xác nhận mới tạo giao dịch.
5. Không cho mượn vượt số lượng khả dụng.
6. Không tự động chọn bài/thiết bị theo thời khóa biểu hoặc AI.
7. Không tự động trả khi qua ngày.
8. Giáo viên chỉ xem dữ liệu cá nhân; Admin xem toàn hệ thống.
9. Phiếu cùng ngày có thể sửa theo quyền; qua ngày giáo viên bị khóa sửa.
10. Admin có thể mở khóa phiếu cũ nhưng bắt buộc ghi lý do và audit log.
11. Lịch sử giao dịch không bị xóa chỉ vì dữ liệu danh mục được cập nhật.
12. Mọi thao tác quan trọng phải có audit log.

### 4. Luồng giáo viên
Đăng nhập → Chọn phòng → Môn + Lớp → Chủ đề → Bài → Danh sách thiết bị → Chọn/số lượng → Xác nhận mượn → Phiếu → Trả.

### 5. Màn hình thiết bị
Context phải thu gọn thành một dòng; danh sách thiết bị 1 cột dọc; vùng danh sách chiếm tối đa không gian; thanh xác nhận cố định cuối màn hình chỉ hiện khi có ít nhất một thiết bị được chọn.

### 6. Dữ liệu
Nguồn dữ liệu ban đầu nhập bằng Excel template. Sau khi kiểm tra/preview, dữ liệu được ghi vào Google Sheets. Form Admin cho phép chỉnh sửa nhanh.

### 7. Trạng thái
Borrow record: DRAFT → BORROWED → RETURNED. Quyền chỉnh sửa theo ngày: EDITABLE_TODAY hoặc LOCKED_BY_DATE. Admin unlock tạo trạng thái/flag UNLOCKED_BY_ADMIN và audit log; sau khi xử lý có thể khóa lại.

### 8. Tồn kho
available = total_quantity - active_borrowed_quantity - blocked_quantity.
Không dùng số “available” nhập tay làm nguồn sự thật.

### 9. Không tự động trả
Qua ngày chỉ thay đổi quyền chỉnh sửa của giáo viên. Phiếu chưa trả vẫn BORROWED; thiết bị vẫn unavailable.

### 10. Bảo toàn lịch sử
Không xóa Borrow Record/Borrow Item khi cập nhật Equipment/Topic. Nếu thiết bị ngừng sử dụng, dùng status INACTIVE.

### 11. Tiêu chí hoàn thành
UI đúng spec; import có validate/preview; mượn/trả cập nhật tồn kho; phân quyền đúng; khóa/mở khóa đúng; audit log đầy đủ; báo cáo cá nhân không lộ dữ liệu người khác; có test concurrency và test qua ngày.
