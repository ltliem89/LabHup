# EXCEL IMPORT SPEC
## File
LAB_HUB_IMPORT_TEMPLATE.xlsx

## Required sheets
ROOMS
SUBJECTS
CLASSES
TOPICS
LESSONS
EQUIPMENT
TOPIC_EQUIPMENT
TEACHERS

## Import pipeline
Upload → file validation → header validation → row validation → relationship validation → duplicate detection → preview → admin confirmation → transaction-safe write → import log.

## Safety
- No destructive delete by omission.
- Existing IDs update only after validation.
- Unknown references are errors.
- Negative quantity is error.
- Duplicate stable IDs are error.
- Historical transactions are never deleted by master-data import.

## Preview
Show new / update / unchanged / errors before commit.
