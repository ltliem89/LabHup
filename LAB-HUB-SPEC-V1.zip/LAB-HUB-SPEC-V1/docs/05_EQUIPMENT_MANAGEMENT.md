# EQUIPMENT MANAGEMENT
## Master record
equipment_id, equipment_code, name, category, room_id, unit, total_quantity, status, image_url, note.

## Status
ACTIVE, INACTIVE, MAINTENANCE, LOST, DAMAGED.

## Availability
available = total - active borrowed - blocked/maintenance/lost quantity.

## Topic mapping
Thiết bị liên kết với Topic bằng TOPIC_EQUIPMENT. Có thể đánh dấu Required và Default_Quantity.

## Admin actions
- Add/edit equipment.
- Bulk import Excel.
- Disable equipment without deleting history.
- Map equipment to topics.
- View inventory.
- View current holders (Admin only).
