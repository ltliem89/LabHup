# APPS SCRIPT SPEC
Apps Script is an API/business-logic layer, not the UI.

## Endpoints/actions
GET bootstrap
GET rooms
GET subjects
GET classes
GET topics
GET lessons
GET equipment
GET myBorrowRecords
POST borrow
POST editBorrow
POST return
POST adminUnlock
POST importData
GET reports

## Required controls
- Authenticate request using an agreed token/session mechanism.
- Authorize role and room access.
- Validate all IDs against Sheets.
- Recalculate inventory server-side.
- Lock critical writes with LockService.
- Generate stable transaction IDs.
- Write audit log for borrow, edit, return, unlock, import and permission changes.

## Error response
{
  ok: false,
  code: "INSUFFICIENT_STOCK",
  message: "Thiết bị không đủ số lượng khả dụng.",
  requestId: "..."
}

Never expose another teacher's private records.
