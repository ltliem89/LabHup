# AI AGENT RULES
1. Read 00_MASTER_SPEC.md before coding.
2. Read relevant module spec before modifying that module.
3. Inspect current source before editing.
4. Never invent missing business rules.
5. Ask the user when a decision changes data architecture, permissions, or destructive behavior.
6. Do not connect real Google data until the user supplies/approves the Sheet and deployment details.
7. Before asking for the Google Sheet, first prepare the Apps Script code and the Sheet schema/template.
8. Work in phases/gates.
9. After each phase run tests.
10. Record changes in DEVELOPMENT_LOG.md.
11. Never claim DONE without evidence.
12. Preserve existing approved UI.
13. No timetable-based or AI-generated lesson/equipment selection.
14. No automatic return across midnight.
15. Never delete historical transaction data because a master record was updated.
16. Never expose other teachers' private data.
17. Use atomic/locked server-side inventory validation.
18. Use idempotency for borrow/return.
19. Keep secrets out of Git.
20. If UI and business spec conflict, stop and ask rather than silently changing the spec.
