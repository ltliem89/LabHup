# TEST PLAN
## UI
- Room selection collapses other rooms.
- Subject/class remain visible together.
- Topic → lessons.
- Equipment screen uses vertical list.
- Bottom confirm appears only after selection.

## Inventory
- 5 total / 4 available → borrow 1 → 3 available.
- Cannot borrow quantity > available.
- Zero available disables selection.
- Return restores availability.

## Concurrency
Two users request last unit simultaneously; only one succeeds.

## Date lock
Borrow today → editable today.
Next calendar date → teacher cannot edit.
Unreturned item remains unavailable.

## Admin unlock
Admin enters reason → record becomes editable → audit log created.

## Privacy
Teacher A cannot retrieve Teacher B's records through UI or API.

## Import
Valid file succeeds after preview.
Duplicate IDs fail.
Unknown references fail.
Negative quantities fail.
Omitted master row does not delete historical transactions.

## Idempotency
Double click/retry with same client_request_id does not create duplicate borrow.

## Export
Teacher export contains only own records.
Admin export contains authorized system data.
