# AUDIT LOG
Audit every important mutation:
- login security event where applicable
- borrow
- borrow edit
- return
- admin unlock
- import
- equipment create/update/status change
- teacher/room permission change

Each entry:
audit_id
actor_id
action
entity_type
entity_id
before_json
after_json
reason
created_at
request_id

Admin unlock MUST contain a non-empty reason.

Audit log is append-only for normal application users.
