# PERMISSION RULES
## Roles
TEACHER, ADMIN.

## Teacher
Can view/edit own records only. Can borrow/return within permitted scope. Cannot see other teachers' transactions or current holders.

## Admin
Can view all, manage master data, import/export, manage teachers, inspect inventory, unlock past records, and view audit log.

## Room authorization
Teacher can only access rooms listed in their authorized_room_ids.

## Past record
Teacher cannot edit after local calendar date changes. Admin can unlock with reason.

## Privacy
API must filter data server-side; hiding UI controls is not sufficient.
