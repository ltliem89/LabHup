# GOOGLE SHEET SCHEMA
## ROOMS
room_id, room_code, room_name, status, note

## SUBJECTS
subject_id, subject_code, subject_name, room_id, status

## CLASSES
class_id, class_code, class_name, grade, school_year, status

## TOPICS
topic_id, topic_code, topic_name, subject_code, grade, order_no, status

## LESSONS
lesson_id, lesson_code, lesson_name, topic_code, order_no, status

## EQUIPMENT
equipment_id, equipment_code, equipment_name, category, room_id, unit, total_quantity, status, image_url, note

## TOPIC_EQUIPMENT
mapping_id, topic_code, equipment_code, default_quantity, required, note, active

## TEACHERS
teacher_id, email, display_name, role, status, authorized_room_ids

## BORROW_RECORDS
borrow_id, teacher_id, room_id, subject_code, class_code, topic_code, lesson_code, borrowed_at, status, editable_until, note

## BORROW_ITEMS
borrow_item_id, borrow_id, equipment_id, quantity, returned_quantity, item_status, incident_id

## INCIDENTS
incident_id, borrow_id, equipment_id, type, quantity, description, image_url, created_at, created_by

## AUDIT_LOG
audit_id, actor_id, action, entity_type, entity_id, before_json, after_json, reason, created_at, request_id
