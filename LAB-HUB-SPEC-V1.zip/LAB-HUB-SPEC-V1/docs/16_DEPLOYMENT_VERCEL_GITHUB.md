# DEPLOYMENT
## Phase A
Google AI Studio produces UI prototype with mock data.

## Phase B
Export source → GitHub repository.

## Phase C
Connect repository to Vercel. Configure environment variables only for non-secret public configuration. Never commit secrets.

## Phase D
OpenAI/Codex reads repository + docs and implements business logic.

## Phase E
Generate Apps Script and configure Google Sheet.

## Phase F
Deploy Apps Script Web App with controlled access, configure endpoint in Vercel.

## Phase G
Run test plan before production.

## Rule
Do not modify production data while testing without explicit test dataset/flag.
