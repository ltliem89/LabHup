# API CONTRACT
## Generic response
Success:
{ "ok": true, "data": ..., "requestId": "..." }

Failure:
{ "ok": false, "code": "...", "message": "...", "requestId": "..." }

## Borrow request
teacher_id, room_id, subject_code, class_code, topic_code, lesson_code, items[], note, client_request_id.

## Item
equipment_id, quantity.

## Return request
borrow_id, items[], incidents[], client_request_id.

## Idempotency
client_request_id must prevent accidental double-submit. Repeating the same confirmed request returns the original result instead of creating a duplicate borrow.
