/**
 * LAB HUB — Apps Script skeleton
 * IMPORTANT:
 * This is a controlled starting point. Production implementation must follow
 * docs/11_APPS_SCRIPT_SPEC.md and docs/12_API_SPEC.md.
 *
 * Do not paste secrets into source control.
 */

function doGet(e) {
  return jsonResponse_({
    ok: true,
    service: "LAB HUB API",
    status: "SKELETON",
    message: "API chưa kết nối dữ liệu thật."
  });
}

function doPost(e) {
  return jsonResponse_({
    ok: false,
    code: "NOT_IMPLEMENTED",
    message: "Apps Script production handlers chưa được triển khai."
  });
}

function jsonResponse_(payload) {
  return ContentService
    .createTextOutput(JSON.stringify(payload))
    .setMimeType(ContentService.MimeType.JSON);
}
