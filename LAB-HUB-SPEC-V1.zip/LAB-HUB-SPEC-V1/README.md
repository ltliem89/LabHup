# LAB HUB — SPEC & DATA PREPARATION KIT V1.0

Bộ đặc tả để phát triển hệ thống quản lý mượn/trả thiết bị phòng thực hành.

## Thành phần
- `docs/` — hợp đồng sản phẩm, UI, dữ liệu, nghiệp vụ, API, quyền, test, deployment, AI agent.
- `templates/LAB_HUB_IMPORT_TEMPLATE.xlsx` — mẫu Excel chuẩn để chuẩn bị dữ liệu.
- `apps-script/Code.gs` — placeholder/khung triển khai Apps Script; OpenAI sẽ hoàn thiện theo spec sau khi người dùng xác nhận Google Sheet.

## Quy trình
1. Dùng Google AI Studio làm UI prototype.
2. Đưa source lên GitHub.
3. Deploy UI lên Vercel.
4. Đưa bộ `docs/` vào repo.
5. Cho OpenAI/Codex đọc spec và audit source.
6. OpenAI chuẩn bị Apps Script + hướng dẫn Google Sheet.
7. Người dùng cung cấp/duyệt Google Sheet.
8. OpenAI kết nối API, test nghiệp vụ, ghi log.

## Nguyên tắc
Thiết bị quản lý theo KHO; liên kết với CHỦ ĐỀ; Bài chỉ là ngữ cảnh của phiếu. Giáo viên không thấy dữ liệu người khác. Qua ngày không tự động trả; chỉ khóa quyền sửa của giáo viên. Admin unlock phải có lý do và audit.
